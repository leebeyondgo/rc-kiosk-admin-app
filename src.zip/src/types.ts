export interface GiftRecord {
    id: string;
    name: string;
    items: string[];
    timestamp?: string;
    location_id: string;
  }