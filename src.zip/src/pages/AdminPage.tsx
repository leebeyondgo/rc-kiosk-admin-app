export default function AdminPage() {
    return <div>관리자 페이지</div>;
  }
  